package com.example.task21;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton imageButton1,imageButton2,imageButton3;
    TextView textView1,textView2,textView3;
    EditText input;
    float number, value1,value2,value3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner);
        imageButton1 = findViewById(R.id.imageButton1);
        imageButton2 = findViewById(R.id.imageButton2);
        imageButton3 = findViewById(R.id.imageButton3);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        input = findViewById(R.id.input);


        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                

                //myTextView.setText(getResources().getString(R.string.myTextViewString) +" " +myEditText.getText().toString());
                if (spinner.getSelectedItem().toString().equals("Meter") )
                {
                    number = Float.parseFloat(input.getText().toString());
                    value1 = 100*number;
                    value2 = (float) ((3.28084)*number);
                    value3 = (float) ((39.3701)*number);

                    textView1.setText( (String.format("%.2f", value1))+ " Centimetre");
                    textView2.setText( (String.format("%.2f", value2))+ " Foot");
                    textView3.setText( (String.format("%.2f", value3))+ " Inch");
                }

                else
                {
                    textView1.setText("");
                    textView2.setText("");
                    textView3.setText("");

                    Toast.makeText( MainActivity.this ,  "Please select the correct conversion icon",Toast.LENGTH_LONG).show();

                }

            }
        });

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //myTextView.setText(getResources().getString(R.string.myTextViewString) +" " +myEditText.getText().toString());
                if (spinner.getSelectedItem().toString().equals("Celsius"))
                {
                    number = Float.parseFloat(input.getText().toString());
                    value1 = (float)(9*number)/5 +32;
                    value2 = (float)(number + 273.151);

                    textView1.setText( (String.format("%.2f", value1))+ " Fahrenheit");
                    textView2.setText( (String.format("%.2f", value2)) + " Kelvin");
                    textView3.setText("");
                }

                else
                {
                    textView1.setText("");
                    textView2.setText("");
                    textView3.setText("");

                    Toast.makeText( MainActivity.this ,  "Please select the correct conversion icon",Toast.LENGTH_LONG).show();

                }

            }
        });

        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //myTextView.setText(getResources().getString(R.string.myTextViewString) +" " +myEditText.getText().toString());
                if (spinner.getSelectedItem().toString().equals("Kilogram"))
                {
                    number = Float.parseFloat(input.getText().toString());
                    value1 = 1000*number;
                    value2 = (float) ((35.274)*number);
                    value3 = (float) ((2.205)*number);

                    textView1.setText( (String.format("%.2f", value1)) + " Grams");
                    textView2.setText( (String.format("%.2f", value2)) + " Ounces(Oz)");
                    textView3.setText( (String.format("%.2f", value3)) + " Pound(lb)");
                }

                else
                {
                    textView1.setText("");
                    textView2.setText("");
                    textView3.setText("");

                    Toast.makeText( MainActivity.this ,  "Please select the correct conversion icon",Toast.LENGTH_LONG).show();

                }

            }
        });


    }
}